#!/bin/sh
java -classpath "../src/zmq.jar:zmq-perf.jar" remote_lat $@